---
description: Implement a feature or code change using the implementer agent
allowed-tools: Agent
---

Invoke the `implementer` agent to implement the following:

$ARGUMENTS
