---
description: Review code changes for critical issues using the code-reviewer agent
allowed-tools: Agent
---

Invoke the `code-reviewer` agent to review the code changes.

If there are specific files or areas to review, include them in the context: $ARGUMENTS
