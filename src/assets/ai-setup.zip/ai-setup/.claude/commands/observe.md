---
description: Explore and understand codebase architecture and patterns using the observer agent
allowed-tools: Agent
---

Invoke the `observer` agent to explore and understand the codebase.

Focus area: $ARGUMENTS
