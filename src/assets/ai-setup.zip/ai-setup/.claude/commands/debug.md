---
description: Find and prove the root cause of a bug using the debugger agent
allowed-tools: Agent
---

Invoke the `debugger` agent to identify and prove the root cause of the bug.

Focus area: $ARGUMENTS
