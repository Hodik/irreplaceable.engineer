---
description: Write comprehensive tests for code/features using the tester agent
allowed-tools: Agent
---

Invoke the `tester` agent to write tests for the specified code or feature.

Test target: $ARGUMENTS
