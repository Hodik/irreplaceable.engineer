install claude setup into project:
npx degit Hodik/ai-setup/.claude .claude && npx degit Hodik/ai-setup/CLAUDE.md CLAUDE.md && npx degit Hodik/ai-setup/docs docs

install cursor setup into project:
npx degit Hodik/ai-setup/.cursor .cursor && npx degit Hodik/ai-setup/docs docs

install everything:
npx degit Hodik/ai-setup
